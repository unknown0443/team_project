def add(a,b):
    # minseok
    c = a+b 
    # kiseong
    d = c
    # hwiho
    e=d
    return d
