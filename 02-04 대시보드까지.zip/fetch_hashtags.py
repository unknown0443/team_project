import re
import django
import os
import sys
from collections import defaultdict, Counter
from googleapiclient.discovery import build
import json

# Django ORM 설정
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.append(project_root)

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings")
django.setup()

from youtube_api.models import HashtagCategory

# 유튜브 API 설정 (API 키 불러오기)
config_path = os.path.join(current_dir, "config.json")
with open(config_path, "r") as config_file:
    config = json.load(config_file)  # JSON 파일을 파싱
    API_KEY = config["YOUTUBE_API_KEY"]
youtube = build("youtube", "v3", developerKey=API_KEY)

# 🔹 초기 장소 리스트 (기존보다 확장)
PLACE_LIST = [
    "해운대", "광안리", "태종대", "감천문화마을", "오륙도", "송정해수욕장", "BIFF광장",
    "자갈치시장", "부산타워", "해동용궁사", "동백섬", "송도해수욕장", "부산시립미술관",
    "국제시장", "송도케이블카", "부산롯데월드", "용두산공원", "부산항대교", "누리마루APEC하우스"
]

# 정규 표현식으로 해시태그 찾기
HASHTAG_PATTERN = re.compile(r"#(\w+)")

def fetch_videos(query, max_results=5):
    """ 특정 장소를 검색하여 유튜브 영상 가져오기 """
    video_ids = []
    next_page_token = None

    while len(video_ids) < max_results:
        request = youtube.search().list(
            q=query,
            part="id",
            type="video",
            maxResults=min(10, max_results - len(video_ids)),
            pageToken=next_page_token
        )
        response = request.execute()

        for item in response.get("items", []):
            video_ids.append(item["id"]["videoId"])

        next_page_token = response.get("nextPageToken")
        if not next_page_token:
            break  # 더 이상 가져올 데이터가 없으면 중단

    return video_ids

def get_video_details(video_ids):
    """ 유튜브 영상 ID 리스트를 입력받아 상세 정보를 가져오는 함수 """
    if not video_ids:  
        print("⚠️ 오류: video_ids 리스트가 비어 있음!")
        return []  # 비어 있을 경우 빈 리스트 반환

    video_data = []
    
    # 유튜브 API 요청은 한 번에 최대 50개까지 가능
    for i in range(0, len(video_ids), 5):
        request = youtube.videos().list(
            part="snippet",
            id=",".join(video_ids[i:i+10])  # 🔹 최대 50개씩 요청
        )
        response = request.execute()

        for item in response.get("items", []):  # 🔹 get("items")로 에러 방지
            video_data.append({
                "video_id": item["id"],
                "title": item["snippet"]["title"],
                "description": item["snippet"].get("description", ""),
                "tags": item["snippet"].get("tags", [])  # 🔹 영상 태그까지 가져오기
            })

    return video_data

def fetch_additional_places():
    """ '부산 가볼만한 곳' 검색하여 새로운 장소 자동 추가 """
    print("🔍 '부산 가볼만한 곳' 검색 중...")
    video_ids = fetch_videos(query="부산 가볼만한 곳", max_results=5)
    videos = get_video_details(video_ids)

    new_places = set()
    for video in videos:
        hashtags = HASHTAG_PATTERN.findall(video["description"])  # 설명에서 해시태그 추출
        new_places.update(hashtags)  # 새로운 장소 후보 저장

    # 기존 장소 리스트에 추가
    additional_places = [place for place in new_places if place not in PLACE_LIST]
    PLACE_LIST.extend(additional_places)

    print(f"✅ 새로운 장소 {len(additional_places)}개 추가 완료!")
    print(f"📌 최종 장소 리스트: {PLACE_LIST}")

HASHTAG_PATTERN = re.compile(r"#(\w+)")

# ✅ 기존 데이터 불러오는 함수

def load_existing_places(file_path):
    """ 기존 해시태그 뒤 장소 데이터를 불러옴 """
    place_counts = Counter()
    if os.path.exists(file_path):
        with open(file_path, "r", encoding="utf-8") as file:
            for line in file:
                try:
                    place, count = line.strip().split(": ")
                    place_counts[place] = int(count)
                except ValueError:
                    continue
    return place_counts

def save_hashtags_to_txt(videos):
    """유튜브 동영상에서 해시태그를 추출하고 TXT 파일로 저장"""
    hashtag_counts = Counter()

    if not videos:
        print("⚠️ 경고: 저장할 동영상 데이터가 없음! (API 호출 문제 가능성)")
        return

    for video in videos:
        hashtags = HASHTAG_PATTERN.findall(video["description"])  
        for hashtag in hashtags:
            hashtag_counts[hashtag] += 1  

    # 🔹 저장할 폴더를 txt 폴더로 변경
    txt_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "txt")
    print(f"📂 생성할 폴더 경로: {txt_dir}")  # ✅ 폴더 경로 확인

    os.makedirs(txt_dir, exist_ok=True)  # ✅ 자동 생성

    file_path = os.path.join(txt_dir, "hashtags.txt")
    print(f"📂 저장할 파일 경로: {file_path}")  # ✅ 저장될 파일 경로 확인

    if not hashtag_counts:
        print("⚠️ 경고: 저장할 해시태그 데이터가 없음!")
        return  

# ✅ 기존 데이터 유지 + 새 데이터 추가
    with open(file_path, "w", encoding="utf-8") as file:
        for hashtag, count in hashtag_counts.items():
            file.write(f"{hashtag}: {count}\n")

    print(f"✅ 해시태그 데이터 저장 완료: {file_path}")

def categorize_places():
    """ 장소 리스트 기반으로 검색하여 해시태그 데이터 확보하고 TXT 파일로 저장 """
    all_video_ids = set()

    for place in PLACE_LIST:
        print(f"🔍 '{place}' 검색 중...")
        video_ids = fetch_videos(query=place, max_results=5)
        all_video_ids.update(video_ids)
        print(f"✅ '{place}'에서 {len(video_ids)}개의 영상 가져옴.")

    print(f"🎬 총 {len(all_video_ids)}개의 유튜브 영상 데이터 수집 완료!")

    video_data = get_video_details(list(all_video_ids))

    if not video_data:
        print("⚠️ 경고: 가져온 영상 데이터가 없음! (API 문제 가능성)")
        return

    # ✅ 반드시 `save_hashtags_to_txt()` 실행
    save_hashtags_to_txt(video_data)

# ✅ 스크립트 실행 시 자동 실행되도록 설정
if __name__ == "__main__":
    print("🔹 YouTube 데이터 수집 시작...")
    categorize_places()  # 🔹 유튜브 데이터를 수집하고 해시태그 저장 실행
    print("✅ 모든 데이터 저장 완료!")
