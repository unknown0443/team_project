from django.db import models
from django.utils.timezone import now

class kakaoplace(models.Model):  # ✅ 클래스명 소문자로 유지
    CATEGORY_CHOICES = [
        ('restaurant', '맛집'),
        ('cafe', '카페'),
        ('tour', '관광지'),
    ]

    name = models.CharField(max_length=255, unique=True)  # ✅ 중복 방지
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    rating = models.FloatField(null=True, blank=True)
    review_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(default=now)

    def __str__(self):
        return f"{self.name} ({self.get_category_display()})"
