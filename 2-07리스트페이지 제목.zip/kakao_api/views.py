import matplotlib
matplotlib.use('Agg')  # ✅ GUI 백엔드 비활성화 (서버에서 실행 가능하도록 설정)
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import os
import numpy as np
from django.shortcuts import render
from django.conf import settings
from .models import kakaoplace

def set_korean_font():
    """ Windows 기본 한글 폰트 (맑은 고딕) 적용 """
    font_path = "C:/Windows/Fonts/malgun.ttf"  # Windows 기본 한글 폰트
    if os.path.exists(font_path):
        plt.rc('font', family=fm.FontProperties(fname=font_path).get_name())
    else:
        plt.rc('font', family='DejaVu Sans')  # 기본 폰트 적용
    plt.rcParams['axes.unicode_minus'] = False  # ✅ 마이너스 기호 깨짐 방지

set_korean_font()  # ✅ 한글 폰트 적용

def calculate_priority_score(places):
    """리뷰 수를 우선적으로 고려한 정렬 방식 적용"""
    for place in places:
        place.priority_score = place.review_count if place.review_count is not None else 0  # ✅ 리뷰 수 기준 정렬
    
    return sorted(places, key=lambda x: (x.priority_score, x.rating if x.rating is not None else 0), reverse=True)[:10]  # ✅ 리뷰 수 우선, 평점 보조 정렬

def dashboard(request):
    """ 대시보드: 맛집, 카페, 관광지 데이터를 한 페이지에서 관리 """
    categories = [
        ("맛집", "restaurant"),
        ("카페", "cafe"),
        ("관광지", "tour"),  # ✅ ORM에서 일치하는 카테고리명 확인
    ]

    category_data = []
    for title, category in categories:
        places = list(kakaoplace.objects.filter(category__icontains=category))  # ✅ 대소문자 구분 없이 카테고리 검색
        
        if not places:
            print(f"⚠️ '{title}' 카테고리 데이터가 없습니다! ORM 쿼리 결과 확인 필요")
        
        top_places = calculate_priority_score(places) if places else []  # ✅ 리뷰 수 우선 정렬 방식 적용
        graph_url = generate_chart(top_places, title) if top_places else ""  # ✅ 데이터 없으면 그래프 생성 X

        category_data.append({
            "title": title,
            "places": top_places,
            "graph_url": graph_url,
        })

    return render(request, 'dashboard.html', {"category_data": category_data})

def generate_chart(places, title):
    """ 맛집/카페/관광지별 그래프 생성 """
    names = []
    review_counts = []
    
    for place in places:
        if place.review_count is not None and isinstance(place.review_count, (int, float)):
            names.append(place.name)
            review_counts.append(place.review_count)
        else:
            names.append(f"{place.name} (리뷰 수 없음)")
            review_counts.append(0)
    
    if not names:
        return ""
    
    plt.figure(figsize=(12, 8))  # ✅ 그래프 크기를 더 크게 조정
    plt.barh(names, review_counts, color='skyblue')
    plt.xlabel('리뷰 수', fontsize=14)
    plt.ylabel('이름', fontsize=14)
    plt.title(f'{title} TOP 10 리뷰 수 비교', fontsize=16)
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    plt.gca().invert_yaxis()
    
    graph_path = os.path.join(settings.MEDIA_ROOT, 'charts')
    os.makedirs(graph_path, exist_ok=True)
    image_path = os.path.join(graph_path, f'{title}_chart.png')
    
    plt.savefig(image_path, format='png', bbox_inches='tight', dpi=150)  # ✅ DPI 증가로 선명도 개선
    plt.close()
    
    return settings.MEDIA_URL + f'charts/{title}_chart.png'

def place_list(request):
    """저장된 모든 장소 데이터를 리스트 형태로 출력"""
    places = kakaoplace.objects.all().order_by('-review_count', '-rating')  # ✅ 리뷰 수 우선 정렬 적용
    return render(request, 'place_list.html', {'places': places})
