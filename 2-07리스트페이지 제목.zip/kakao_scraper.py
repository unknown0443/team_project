import time
import os
import django
import sys
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from django.db import transaction

# Django 프로젝트 설정 로드
current_dir = os.path.dirname(os.path.abspath(__file__))
project_root = os.path.dirname(current_dir)
sys.path.append(project_root)

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'config.settings')
django.setup()

from kakao_api.models import kakaoplace

def save_place_to_db(place_name, rating, review_count, category):
    """ 장소 데이터를 데이터베이스에 저장 """
    with transaction.atomic():
        place_obj, created = kakaoplace.objects.update_or_create(
            name=place_name,
            defaults={
                "rating": rating,
                "review_count": review_count,
                "category": category
            }
        )
        if created:
            print(f"✅ 새 데이터 저장: {place_name} ({category}) - ⭐ {rating} | 💬 {review_count}")
        else:
            print(f"🔄 기존 데이터 업데이트: {place_name} ({category}) - ⭐ {rating} | 💬 {review_count}")

def get_places_details(place_name, category, is_last_category=False, max_results=200):
    """ 카카오 지도에서 맛집, 카페, 관광지를 크롤링 (페이지네이션 순서대로 크롤링) """

    options = Options()
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    options.add_argument("--disable-gpu")
    options.add_argument("--log-level=3")
    options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36")

    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    try:
        search_url = f"https://map.kakao.com/?q={place_name}"
        print(f"🔍 '{place_name}' ({category}) 검색 중... ({search_url})")
        driver.get(search_url)

        try:
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'li.PlaceItem'))
            )
        except Exception:
            print(f"❌ '{place_name}' 검색 결과를 찾을 수 없습니다.")
            return None

        # ✅ "인기도순" 버튼 클릭
        try:
            popular_button = driver.find_element(By.XPATH, "//a[contains(text(), '인기도순')]")
            driver.execute_script("arguments[0].click();", popular_button)
            time.sleep(3)  
            WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.CSS_SELECTOR, 'li.PlaceItem'))
            )
            print("📊 '인기도순' 정렬 적용 완료")
        except Exception:
            print("⚠️ '인기도순' 버튼을 찾을 수 없습니다. 기본 정렬로 진행합니다.")

        results = set()  

        while len(results) < max_results:
            print(f"📄 현재까지 크롤링된 장소 수: {len(results)}개")

            while True:  
                try:
                    page_numbers = driver.find_elements(By.CSS_SELECTOR, 'div#info\\.search\\.page a')

                    for page in page_numbers:
                        try:
                            page_num = page.text.strip()
                            if not page_num.isdigit():
                                continue  

                            print(f"🔄 페이지 {page_num} 크롤링 중...")
                            driver.execute_script("arguments[0].click();", page)
                            time.sleep(3)  

                            WebDriverWait(driver, 10).until(
                                EC.presence_of_element_located((By.CSS_SELECTOR, 'li.PlaceItem'))
                            )

                            places = driver.find_elements(By.CSS_SELECTOR, 'li.PlaceItem')

                            if not places:
                                print("🚫 장소 데이터를 찾을 수 없습니다.")
                                break

                            for place in places:
                                if len(results) >= max_results:
                                    break

                                try:
                                    place_name = place.find_element(By.CSS_SELECTOR, 'a.link_name').text
                                    rating = place.find_element(By.CSS_SELECTOR, 'em.num').text
                                    review_count = place.find_element(By.CSS_SELECTOR, 'a.review em').text

                                    rating = float(rating) if rating else None
                                    review_count = int(review_count.replace(',', '')) if review_count else None

                                    if place_name not in results:
                                        results.add(place_name)
                                        save_place_to_db(place_name, rating, review_count, category)

                                except Exception as e:
                                    print("⚠️ 장소 정보를 가져오는 데 실패:", e)

                        except Exception:
                            print(f"🚫 페이지 {page_num} 클릭 실패")

                    # ✅ "다음" 버튼 클릭 (클릭할 수 없으면 종료)
                    try:
                        next_button = driver.find_element(By.CSS_SELECTOR, 'button#info\\.search\\.page\\.next')
                        if "disabled" in next_button.get_attribute("class"):
                            raise Exception("🚫 다음 버튼이 비활성화됨")
                        
                        driver.execute_script("arguments[0].click();", next_button)
                        time.sleep(3)

                        WebDriverWait(driver, 10).until(
                            EC.presence_of_element_located((By.CSS_SELECTOR, 'li.PlaceItem'))
                        )
                    except Exception:
                        print(f"✅ '{place_name}' 크롤링 종료 (다음 검색어로 이동)")
                        return results  

                except Exception:
                    print("🚫 페이지네이션 숫자를 찾을 수 없습니다.")
                    break

        return results

    except Exception as e:
        print("❌ 크롤링 실패:", e)
        return None

    finally:
        driver.quit()

# 🔹 **검색어별 크롤링 실행 (순차적으로 진행)**
if __name__ == "__main__":
    categories = {
        "부산 맛집": "restaurant",
        "부산 카페": "cafe",
        "부산 관광지": "tour",
    }

    category_list = list(categories.items())

    for i, (search_term, category) in enumerate(category_list):
        is_last = (i == len(category_list) - 1)  # 마지막 검색어인지 확인
        print(f"\n🔍 **'{search_term}' 크롤링 시작...**")
        results = get_places_details(search_term, category, is_last_category=is_last, max_results=200)

        if results:
            print(f"\n✅ **'{search_term}' 크롤링 완료 ({len(results)}개 저장됨)**")
        else:
            print(f"\n⚠️ '{search_term}'에서 크롤링된 데이터가 없습니다.")

    print("\n🎉 모든 크롤링이 완료되었습니다! 🚀")
